
        window.onscroll = function () {
      updateProgressBar();
      showBackToTopButton();
    };

    function updateProgressBar() {
      var winScroll =
        document.body.scrollTop || document.documentElement.scrollTop;
      var height =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;
      var scrolled = (winScroll / height) * 100;
      document.getElementById("myBar").style.width = scrolled + "%";
    }

    function showBackToTopButton() {
      const backToTopButton = document.getElementById("myBtn");
      const nav = document.querySelector("nav");
      const navHeight = nav.offsetHeight;
      const distanceFromTop = nav.getBoundingClientRect().top;
      
      if (distanceFromTop <= -navHeight) {
        backToTopButton.classList.add("show");
      } else {
        backToTopButton.classList.remove("show");
      }
    }

    function scrollToTop() {
      const scrollDuration = 500; // Duration of the animation in milliseconds
      const scrollStep = -window.scrollY / (scrollDuration / 15);

      const scrollInterval = setInterval(() => {
        if (window.scrollY !== 0) {
          window.scrollBy(0, scrollStep);
        } else {
          clearInterval(scrollInterval);
        }
      }, 15);
    }

        const salinBtn = document.getElementById('salinBtn');
        const artikel = document.getElementById('artikel');
    
        salinBtn.addEventListener('click', () => {
          // Membuat elemen seleksi teks
          const range = document.createRange();
          range.selectNode(artikel);
    
          // Memilih teks dan menyalinnya ke clipboard
          const seleksi = window.getSelection();
          seleksi.removeAllRanges();
          seleksi.addRange(range);
    
          document.execCommand('copy');
    
          // Membersihkan seleksi teks
          seleksi.removeAllRanges();
    
          // Ganti ikon menjadi checkmark
          salinBtn.innerHTML = '<ion-icon name="checkmark-outline"></ion-icon>';
    
          // Kembalikan ikon ke keadaan semula setelah 5 detik
          setTimeout(() => {
            salinBtn.innerHTML = '<ion-icon name="clipboard-outline"></ion-icon>';
          }, 3000);
        });


        const downloadBtn = document.getElementById('downloadBtn');
    
        downloadBtn.addEventListener('click', () => {
          // Ganti ikon menjadi checkmark dan tambahkan class "success" untuk CSS
          downloadBtn.innerHTML = '<ion-icon name="checkmark-outline"></ion-icon>';
          downloadBtn.classList.add('success');
    
          // Simulasikan pengunduhan file PDF (gunakan link sesuai kebutuhan Anda)
          // Di sini, kita gunakan fungsi setTimeout untuk menampilkan ikon centang selama 3 detik
          setTimeout(() => {
            downloadBtn.innerHTML = '<ion-icon name="cloud-download-outline"></ion-icon>';
            downloadBtn.classList.remove('success');
          }, 3000);
        });



        const shareBtn = document.getElementById('shareBtn');
    
        // Fungsi untuk menangani klik tombol Share
        function handleShare() {
          // Periksa apakah Web Share API didukung di peramban
          if (navigator.share) {
            // Berikan tautan yang ingin Anda bagikan
            const shareData = {
              title: document.title,
              text: 'Check out this awesome website!',
              url: window.location.href
            };
    
            // Panggil metode share()
            navigator.share(shareData)
              .then(() => console.log('Berhasil berbagi!'))
              .catch((error) => console.log('Error sharing:', error));
          } else {
            // Tindakan alternatif jika Web Share API tidak didukung
            alert('Web Share API tidak didukung di peramban ini. Anda dapat mencoba di peramban yang lebih baru.');
          }
        }
    
        // Tambahkan event listener untuk klik tombol Share
        shareBtn.addEventListener('click', handleShare);

        